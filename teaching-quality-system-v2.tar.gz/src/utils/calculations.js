// 计算公式工具

// 高分率 = 高分人数 / 实考人数 * 100
export function calcHighScoreRate(highCount, actualCount) {
  if (!actualCount) return 0;
  return Number((highCount / actualCount * 100).toFixed(2));
}

// 及格率 = 及格人数 / 实考人数 * 100
export function calcPassRate(passCount, actualCount) {
  if (!actualCount) return 0;
  return Number((passCount / actualCount * 100).toFixed(2));
}

// 低分率 = 低分人数 / 实考人数 * 100
export function calcLowRate(lowCount, actualCount) {
  if (!actualCount) return 0;
  return Number((lowCount / actualCount * 100).toFixed(2));
}

// 人平分率 = 人平分 / 100 * 100
export function calcAvgRate(avgScore) {
  if (!avgScore) return 0;
  return Number((avgScore / 100 * 100).toFixed(2));
}

// 综合指数 = (高分率 + 及格率 + 人平分率 - 低分率) / 3
export function calcCompositeIndex(highRate, passRate, avgRate, lowRate) {
  return Number(((highRate + passRate + avgRate - lowRate) / 3).toFixed(4));
}

// 计算所有比率
export function calcAllRates(record) {
  const { highCount, actualCount, passCount, lowCount, avgScore } = record;
  
  const highRate = calcHighScoreRate(highCount, actualCount);
  const passRate = calcPassRate(passCount, actualCount);
  const lowRate = calcLowRate(lowCount, actualCount);
  const avgRate = calcAvgRate(avgScore);
  const compositeIndex = calcCompositeIndex(highRate, passRate, avgRate, lowRate);
  
  return { highRate, passRate, lowRate, avgRate, compositeIndex };
}

// 计算年级平均综合指数
export function calcGradeAvgIndex(records, grade, subject) {
  const filtered = records.filter(r => r.grade === grade && r.subject === subject);
  if (filtered.length === 0) return 0;
  
  const sum = filtered.reduce((acc, r) => acc + r.compositeIndex, 0);
  return Number((sum / filtered.length).toFixed(4));
}

// 计算与年级第一的差值
export function calcDiffFromFirst(records, record) {
  const sameGradeSubject = records.filter(
    r => r.grade === record.grade && r.subject === record.subject
  );
  if (sameGradeSubject.length === 0) return 0;
  
  const maxIndex = Math.max(...sameGradeSubject.map(r => r.compositeIndex));
  return Number((record.compositeIndex - maxIndex).toFixed(4));
}

// 计算净升率
export function calcNetRise(currentIndex, lastSemesterIndex) {
  if (!lastSemesterIndex) return 0;
  return Number((currentIndex - lastSemesterIndex).toFixed(4));
}

// 格式化学年度选项
export const schoolYears = [];
for (let y = 2020; y <= 2030; y++) {
  schoolYears.push(`${y}-${y + 1}`);
}

// 学期选项
export const semesters = ['上学期', '下学期'];

// 年级选项
export const grades = [1, 2, 3, 4, 5, 6];

// 班级选项
export const classes = [1, 2, 3, 4, 5];

// 学科选项
export const subjects = ['语文', '数学', '英语', '道德与法治', '科学', '体育', '音乐', '美术', '信息技术'];

// Excel模板列
export const excelColumns = [
  '学年度', '学期', '学科', '年级', '班级', '任课教师',
  '应考人数', '实考人数', '高分人数', '及格人数', '低分人数', '人平分'
];
