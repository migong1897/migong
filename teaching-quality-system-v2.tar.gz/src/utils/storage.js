// localStorage 数据存储

const DATA_KEY = 'teaching_quality_data';
const USER_KEY = 'teaching_quality_user';

// 获取所有数据
export function getAllData() {
  const data = localStorage.getItem(DATA_KEY);
  return data ? JSON.parse(data) : [];
}

// 保存所有数据
export function saveAllData(data) {
  localStorage.setItem(DATA_KEY, JSON.stringify(data));
}

// 添加单条记录
export function addRecord(record) {
  const data = getAllData();
  record.id = Date.now().toString();
  record.createdAt = new Date().toISOString();
  data.push(record);
  saveAllData(data);
  return record;
}

// 更新记录
export function updateRecord(id, updates) {
  const data = getAllData();
  const index = data.findIndex(r => r.id === id);
  if (index !== -1) {
    data[index] = { ...data[index], ...updates, updatedAt: new Date().toISOString() };
    saveAllData(data);
    return data[index];
  }
  return null;
}

// 删除记录
export function deleteRecord(id) {
  const data = getAllData();
  const filtered = data.filter(r => r.id !== id);
  saveAllData(filtered);
}

// 批量导入数据
export function importData(records) {
  const data = getAllData();
  const newRecords = records.map(r => ({
    ...r,
    id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    createdAt: new Date().toISOString()
  }));
  saveAllData([...data, ...newRecords]);
  return newRecords.length;
}

// 用户登录
export function login(username, password) {
  const user = { username, role: username === 'admin' ? 'admin' : 'teacher' };
  localStorage.setItem(USER_KEY, JSON.stringify(user));
  return user;
}

// 退出登录
export function logout() {
  localStorage.removeItem(USER_KEY);
}

// 获取当前用户
export function getCurrentUser() {
  const user = localStorage.getItem(USER_KEY);
  return user ? JSON.parse(user) : null;
}

// 检查是否已登录
export function isLoggedIn() {
  return !!localStorage.getItem(USER_KEY);
}
