import * as XLSX from 'xlsx';
import { calcAllRates } from './calculations';

// Excel模板列名
const columns = [
  '学年度', '学期', '学科', '年级', '班级', '任课教师',
  '应考人数', '实考人数', '高分人数', '及格人数', '低分人数', '人平分'
];

// 字段映射
const fieldMap = {
  '学年度': 'schoolYear',
  '学期': 'semester',
  '学科': 'subject',
  '年级': 'grade',
  '班级': 'classNum',
  '任课教师': 'teacher',
  '应考人数': 'expectedCount',
  '实考人数': 'actualCount',
  '高分人数': 'highCount',
  '及格人数': 'passCount',
  '低分人数': 'lowCount',
  '人平分': 'avgScore'
};

// 导入Excel
export function importExcel(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target.result);
        const workbook = XLSX.read(data, { type: 'array' });
        const sheetName = workbook.SheetNames[0];
        const sheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        
        if (json.length < 2) {
          reject(new Error('Excel文件为空或格式不正确'));
          return;
        }
        
        const headers = json[0];
        const records = [];
        
        for (let i = 1; i < json.length; i++) {
          const row = json[i];
          if (!row || row.length === 0 || !row[0]) continue;
          
          const record = { _raw: row };
          headers.forEach((header, index) => {
            const field = fieldMap[header];
            if (field && row[index] !== undefined) {
              record[field] = row[index];
            }
          });
          
          // 计算各项比率
          const rates = calcAllRates(record);
          Object.assign(record, rates);
          
          records.push(record);
        }
        
        resolve(records);
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = () => reject(new Error('读取文件失败'));
    reader.readAsArrayBuffer(file);
  });
}

// 导出Excel
export function exportExcel(data, filename = '教学质量数据') {
  const exportData = data.map(record => ({
    '学年度': record.schoolYear,
    '学期': record.semester,
    '学科': record.subject,
    '年级': record.grade,
    '班级': record.classNum,
    '任课教师': record.teacher,
    '应考人数': record.expectedCount,
    '实考人数': record.actualCount,
    '高分人数': record.highCount,
    '及格人数': record.passCount,
    '低分人数': record.lowCount,
    '人平分': record.avgScore,
    '高分率': record.highRate,
    '及格率': record.passRate,
    '低分率': record.lowRate,
    '人平分率': record.avgRate,
    '综合指数': record.compositeIndex
  }));
  
  const ws = XLSX.utils.json_to_sheet(exportData);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '数据');
  XLSX.writeFile(wb, `${filename}.xlsx`);
}

// 生成模板
export function downloadTemplate() {
  const template = [columns];
  const ws = XLSX.utils.aoa_to_sheet(template);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, '模板');
  XLSX.writeFile(wb, '教学质量数据导入模板.xlsx');
}
