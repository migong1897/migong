import React from 'react';
import { Typography, Space } from 'antd';
import { UserOutlined } from '@ant-design/icons';
import { getCurrentUser } from '../utils/storage.js';

const { Title, Text } = Typography;

const Header = ({ title }) => {
  const user = getCurrentUser();

  return (
    <div className="header">
      <Title level={4} style={{ margin: 0 }}>{title}</Title>
      <Space>
        <UserOutlined />
        <Text>{user?.username || '用户'}</Text>
      </Space>
    </div>
  );
};

export default Header;
