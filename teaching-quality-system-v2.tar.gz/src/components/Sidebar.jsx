import React from 'react';
import { Layout, Menu } from 'antd';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  DashboardOutlined,
  PlusCircleOutlined,
  TableOutlined,
  ImportOutlined,
  BarChartOutlined,
  LineChartOutlined,
  AreaChartOutlined,
  LogoutOutlined
} from '@ant-design/icons';
import { logout } from '../utils/storage';

const { Sider } = Layout;

const menuItems = [
  { key: '/', icon: <DashboardOutlined />, label: '首页概览' },
  { key: '/entry', icon: <PlusCircleOutlined />, label: '数据录入' },
  { key: '/list', icon: <TableOutlined />, label: '数据列表' },
  { key: '/import', icon: <ImportOutlined />, label: 'Excel导入' },
  { key: '/horizontal', icon: <BarChartOutlined />, label: '横向对比' },
  { key: '/vertical', icon: <LineChartOutlined />, label: '纵向跟踪' },
  { key: '/charts', icon: <AreaChartOutlined />, label: '可视化图表' },
];

const Sidebar = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };

  return (
    <Sider theme="dark" style={{ height: '100vh', position: 'fixed', left: 0, top: 0 }}>
      <div className="logo" style={{ padding: '16px', textAlign: 'center', color: 'white' }}>
        <div style={{ fontSize: '16px', fontWeight: 'bold' }}>米公小学</div>
        <div style={{ fontSize: '12px', opacity: 0.8 }}>教学质量分析系统</div>
      </div>
      <Menu
        theme="dark"
        mode="inline"
        selectedKeys={[location.pathname]}
        items={menuItems}
        onClick={({ key }) => navigate(key)}
      />
      <div style={{ position: 'absolute', bottom: 60, width: '100%', padding: '0 16px' }}>
        <div
          onClick={handleLogout}
          style={{ color: '#fff', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8 }}
        >
          <LogoutOutlined /> 退出登录
        </div>
      </div>
    </Sider>
  );
};

export default Sidebar;
