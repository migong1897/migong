import React, { useState, useEffect } from 'react';
import { Form, Input, InputNumber, Select, Button, Card, message, Row, Col } from 'antd';
import { addRecord } from '../utils/storage';
import { calcAllRates, schoolYears, semesters, grades, classes, subjects } from '../utils/calculations';

const DataEntry = () => {
  const [form] = Form.useForm();
  const [calculatedValues, setCalculatedValues] = useState({});

  const onValuesChange = (changedValues, allValues) => {
    if (changedValues.highCount !== undefined || changedValues.actualCount !== undefined ||
        changedValues.passCount !== undefined || changedValues.lowCount !== undefined || 
        changedValues.avgScore !== undefined) {
      const values = form.getFieldsValue();
      const rates = calcAllRates(values);
      setCalculatedValues(rates);
    }
  };

  const onFinish = (values) => {
    const record = {
      ...values,
      ...calculatedValues,
      compositeIndex: calculatedValues.compositeIndex || 0
    };
    addRecord(record);
    message.success('数据录入成功！');
    form.resetFields();
    setCalculatedValues({});
  };

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">➕ 数据录入</h1>
      
      <Card>
        <Form
          form={form}
          layout="vertical"
          onValuesChange={onValuesChange}
          onFinish={onFinish}
        >
          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="schoolYear" label="学年度" rules={[{ required: true }]}>
                <Select options={schoolYears.map(y => ({ label: y, value: y }))} placeholder="请选择学年度" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="semester" label="学期" rules={[{ required: true }]}>
                <Select options={semesters.map(s => ({ label: s, value: s }))} placeholder="请选择学期" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="subject" label="学科" rules={[{ required: true }]}>
                <Select options={subjects.map(s => ({ label: s, value: s }))} placeholder="请选择学科" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={8}>
              <Form.Item name="grade" label="年级" rules={[{ required: true }]}>
                <Select options={grades.map(g => ({ label: `${g}年级`, value: g }))} placeholder="请选择年级" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="classNum" label="班级" rules={[{ required: true }]}>
                <Select options={classes.map(c => ({ label: `${c}班`, value: c }))} placeholder="请选择班级" />
              </Form.Item>
            </Col>
            <Col span={8}>
              <Form.Item name="teacher" label="任课教师">
                <Input placeholder="请输入任课教师" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={6}>
              <Form.Item name="expectedCount" label="应考人数" rules={[{ required: true }]}>
                <InputNumber min={0} style={{ width: '100%' }} placeholder="应考人数" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name="actualCount" label="实考人数" rules={[{ required: true }]}>
                <InputNumber min={0} style={{ width: '100%' }} placeholder="实考人数" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name="highCount" label="高分人数" rules={[{ required: true }]}>
                <InputNumber min={0} style={{ width: '100%' }} placeholder="高分人数" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name="passCount" label="及格人数" rules={[{ required: true }]}>
                <InputNumber min={0} style={{ width: '100%' }} placeholder="及格人数" />
              </Form.Item>
            </Col>
          </Row>

          <Row gutter={16}>
            <Col span={6}>
              <Form.Item name="lowCount" label="低分人数" rules={[{ required: true }]}>
                <InputNumber min={0} style={{ width: '100%' }} placeholder="低分人数" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item name="avgScore" label="人平分" rules={[{ required: true }]}>
                <InputNumber min={0} max={150} style={{ width: '100%' }} placeholder="人平分" />
              </Form.Item>
            </Col>
            <Col span={6}>
              <Form.Item label="综合指数">
                <Input value={calculatedValues.compositeIndex || '-'} disabled />
              </Form.Item>
            </Col>
          </Row>

          <Form.Item style={{ marginTop: 24 }}>
            <Button type="primary" htmlType="submit" size="large">
              提交数据
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </div>
  );
};

export default DataEntry;
