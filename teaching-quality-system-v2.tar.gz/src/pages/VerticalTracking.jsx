import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Select, Table } from 'antd';
import ReactECharts from 'echarts-for-react';
import { getAllData } from '../utils/storage';

const VerticalTracking = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState({
    grade: 1,
    classNum: 1,
    subject: '语文'
  });

  useEffect(() => {
    setData(getAllData());
  }, []);

  const getTrendData = () => {
    return data
      .filter(d => d.grade === filter.grade && d.classNum === filter.classNum && d.subject === filter.subject)
      .sort((a, b) => {
        const yearA = parseInt(a.schoolYear.split('-')[0]);
        const yearB = parseInt(b.schoolYear.split('-')[0]);
        if (yearA !== yearB) return yearA - yearB;
        return a.semester === '上学期' ? -1 : 1;
      });
  };

  const getLineChartOption = () => {
    const trendData = getTrendData();
    if (trendData.length === 0) return {};

    return {
      title: { text: '班级历年人平分趋势', left: 'center' },
      tooltip: { trigger: 'axis' },
      xAxis: {
        type: 'category',
        data: trendData.map(d => `${d.schoolYear}${d.semester}`)
      },
      yAxis: { type: 'value', name: '综合指数' },
      series: [{
        type: 'line',
        data: trendData.map(d => d.compositeIndex),
        smooth: true,
        areaStyle: { color: 'rgba(24, 144, 255, 0.3)' },
        lineStyle: { color: '#1890ff', width: 3 },
        itemStyle: { color: '#1890ff' },
        label: { show: true, position: 'top', formatter: (p) => p.value.toFixed(4) }
      }]
    };
  };

  const getSubjectCompareOption = () => {
    const gradeData = data.filter(d => d.grade === filter.grade && d.classNum === filter.classNum);
    const subjectAvg = {};
    
    [...new Set(gradeData.map(d => d.subject))].forEach(subject => {
      const subjectData = gradeData.filter(d => d.subject === subject);
      if (subjectData.length > 0) {
        subjectAvg[subject] = subjectData.reduce((sum, d) => sum + d.compositeIndex, 0) / subjectData.length;
      }
    });

    const sortedSubjects = Object.entries(subjectAvg).sort((a, b) => b[1] - a[1]);

    return {
      title: { text: '班级各学科平均综合指数', left: 'center' },
      tooltip: { trigger: 'axis' },
      xAxis: { type: 'category', data: sortedSubjects.map(s => s[0]) },
      yAxis: { type: 'value', name: '综合指数' },
      series: [{
        type: 'bar',
        data: sortedSubjects.map(([_, value]) => ({
          value: value.toFixed(4),
          itemStyle: { color: value > 20 ? '#52c41a' : value > 15 ? '#1890ff' : '#ff4d4f' }
        })),
        label: { show: true, position: 'top', formatter: (p) => p.value }
      }]
    };
  };

  const getTeacherTrendOption = () => {
    const teacherData = data.filter(d => d.teacher && d.subject === filter.subject);
    const teacherMap = {};
    
    teacherData.forEach(d => {
      if (!teacherMap[d.teacher]) {
        teacherMap[d.teacher] = [];
      }
      teacherMap[d.teacher].push({
        label: `${d.schoolYear}${d.semester}`,
        value: d.compositeIndex
      });
    });

    return {
      title: { text: '教师历年教学成绩', left: 'center' },
      tooltip: { trigger: 'axis' },
      legend: { data: Object.keys(teacherMap), bottom: 0 },
      xAxis: { type: 'category', data: [...new Set(teacherData.map(d => `${d.schoolYear}${d.semester}`))] },
      yAxis: { type: 'value', name: '综合指数' },
      series: Object.entries(teacherMap).map(([teacher, points]) => ({
        name: teacher,
        type: 'line',
        data: points.sort((a, b) => a.label.localeCompare(b.label)).map(p => p.value)
      }))
    };
  };

  const trendData = getTrendData();

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">📈 纵向跟踪</h1>
      
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Select
            value={filter.grade}
            style={{ width: 100 }}
            onChange={(val) => setFilter({ ...filter, grade: val })}
            options={[1,2,3,4,5,6].map(g => ({ label: `${g}年级`, value: g }))}
          />
          <Select
            value={filter.classNum}
            style={{ width: 100 }}
            onChange={(val) => setFilter({ ...filter, classNum: val })}
            options={[1,2,3,4,5].map(c => ({ label: `${c}班`, value: c }))}
          />
          <Select
            value={filter.subject}
            style={{ width: 120 }}
            onChange={(val) => setFilter({ ...filter, subject: val })}
            options={['语文', '数学', '英语', '科学'].map(s => ({ label: s, value: s }))}
          />
        </div>
      </Card>

      <Row gutter={16}>
        <Col span={12}>
          <Card>
            <ReactECharts option={getLineChartOption()} style={{ height: 350 }} />
          </Card>
        </Col>
        <Col span={12}>
          <Card>
            <ReactECharts option={getSubjectCompareOption()} style={{ height: 350 }} />
          </Card>
        </Col>
      </Row>

      <Card style={{ marginTop: 16 }}>
        <ReactECharts option={getTeacherTrendOption()} style={{ height: 400 }} />
      </Card>

      <Card style={{ marginTop: 16 }}>
        <Table 
          title={() => '历史数据记录'}
          columns={[
            { title: '学年度', dataIndex: 'schoolYear', key: 'schoolYear' },
            { title: '学期', dataIndex: 'semester', key: 'semester' },
            { title: '教师', dataIndex: 'teacher', key: 'teacher' },
            { title: '综合指数', dataIndex: 'compositeIndex', key: 'compositeIndex', render: (v) => v?.toFixed(4) },
            { title: '人平分', dataIndex: 'avgScore', key: 'avgScore' },
          ]}
          dataSource={trendData}
          rowKey="id"
          size="small"
          pagination={false}
        />
      </Card>
    </div>
  );
};

export default VerticalTracking;
