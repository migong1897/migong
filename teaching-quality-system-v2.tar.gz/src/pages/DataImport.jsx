import React, { useState } from 'react';
import { Upload, Button, message, Card, Table, Select } from 'antd';
import { UploadOutlined, FileExcelOutlined, DownloadOutlined } from '@ant-design/icons';
import { importExcel, downloadTemplate } from '../utils/export';
import { importData } from '../utils/storage';
import { useNavigate } from 'react-router-dom';

const DataImport = () => {
  const [fileList, setFileList] = useState([]);
  const [previewData, setPreviewData] = useState([]);
  const [uploading, setUploading] = useState(false);
  const navigate = useNavigate();

  const handleUpload = async (file) => {
    if (!file.name.match(/\.(xlsx|xls)$/i)) {
      message.error('请上传 Excel 文件！');
      return false;
    }

    setUploading(true);
    try {
      const data = await importExcel(file);
      setPreviewData(data);
      message.success(`读取到 ${data.length} 条数据`);
    } catch (error) {
      message.error('读取文件失败：' + error.message);
    }
    setUploading(false);
    return false;
  };

  const handleImport = () => {
    if (previewData.length === 0) {
      message.warning('请先上传文件');
      return;
    }
    const count = importData(previewData);
    message.success(`成功导入 ${count} 条数据！`);
    setPreviewData([]);
    setFileList([]);
  };

  const columns = [
    { title: '学年度', dataIndex: 'schoolYear', key: 'schoolYear', width: 100 },
    { title: '学期', dataIndex: 'semester', key: 'semester', width: 70 },
    { title: '年级', dataIndex: 'grade', key: 'grade', width: 60 },
    { title: '班级', dataIndex: 'classNum', key: 'classNum', width: 60 },
    { title: '学科', dataIndex: 'subject', key: 'subject', width: 80 },
    { title: '教师', dataIndex: 'teacher', key: 'teacher', width: 80 },
    { title: '实考', dataIndex: 'actualCount', key: 'actualCount', width: 60 },
    { title: '高分率', dataIndex: 'highRate', key: 'highRate', width: 80 },
    { title: '及格率', dataIndex: 'passRate', key: 'passRate', width: 80 },
    { title: '综合指数', dataIndex: 'compositeIndex', key: 'compositeIndex', width: 100 },
  ];

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">📤 Excel导入</h1>
      
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 16, alignItems: 'center', marginBottom: 24 }}>
          <Upload
            fileList={fileList}
            beforeUpload={handleUpload}
            onChange={({ fileList }) => setFileList(fileList)}
            accept=".xlsx,.xls"
          >
            <Button icon={<UploadOutlined />} loading={uploading}>
              选择Excel文件
            </Button>
          </Upload>
          
          <Button icon={<DownloadOutlined />} onClick={downloadTemplate}>
            下载模板
          </Button>

          <Button 
            type="primary" 
            icon={<FileExcelOutlined />} 
            onClick={handleImport}
            disabled={previewData.length === 0}
          >
            确认导入 ({previewData.length} 条)
          </Button>
        </div>

        <div style={{ color: '#666', marginBottom: 16 }}>
          <p><strong>导入说明：</strong></p>
          <ul style={{ paddingLeft: 20 }}>
            <li>请先下载模板，按模板格式填写数据</li>
            <li>必填字段：学年度、学期、学科、年级、班级、应考人数、实考人数、高分人数、及格人数、低分人数、人平分</li>
            <li>系统会自动计算高分率、及格率、低分率、人平分率、综合指数</li>
            <li>支持 .xlsx 和 .xls 格式</li>
          </ul>
        </div>
      </Card>

      {previewData.length > 0 && (
        <Card title="数据预览">
          <Table
            columns={columns}
            dataSource={previewData}
            rowKey={(record, index) => index}
            pagination={{ pageSize: 10 }}
            size="small"
            scroll={{ x: 1000 }}
          />
        </Card>
      )}
    </div>
  );
};

export default DataImport;
