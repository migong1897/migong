import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Select, Table } from 'antd';
import ReactECharts from 'echarts-for-react';
import { getAllData } from '../utils/storage';
import { calcGradeAvgIndex, calcDiffFromFirst, schoolYears, semesters, grades, subjects } from '../utils/calculations';

const HorizontalCompare = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState({
    schoolYear: schoolYears[schoolYears.length - 1],
    semester: '上学期',
    grade: 1,
    subject: '语文'
  });

  useEffect(() => {
    setData(getAllData());
  }, []);

  const getFilteredData = () => {
    return data.filter(d => 
      d.schoolYear === filter.schoolYear &&
      d.semester === filter.semester &&
      d.grade === filter.grade &&
      d.subject === filter.subject
    );
  };

  const getChartOption = () => {
    const filtered = getFilteredData();
    if (filtered.length === 0) return {};

    const gradeAvg = calcGradeAvgIndex(data, filter.grade, filter.subject);
    const maxIndex = Math.max(...filtered.map(d => d.compositeIndex));

    return {
      title: {
        text: `${filter.grade}年级${filter.subject}各班综合指数对比`,
        left: 'center'
      },
      tooltip: { trigger: 'axis' },
      legend: {
        data: ['综合指数', '年级平均'],
        bottom: 0
      },
      xAxis: {
        type: 'category',
        data: filtered.map(d => `${d.classNum}班`)
      },
      yAxis: { type: 'value', name: '综合指数' },
      series: [
        {
          name: '综合指数',
          type: 'bar',
          data: filtered.map(d => ({
            value: d.compositeIndex,
            itemStyle: { color: d.compositeIndex === maxIndex ? '#52c41a' : '#1890ff' }
          })),
          label: { show: true, position: 'top', formatter: (p) => p.value.toFixed(4) }
        },
        {
          name: '年级平均',
          type: 'line',
          data: filtered.map(() => gradeAvg),
          lineStyle: { type: 'dashed', color: '#faad14' },
          itemStyle: { color: '#faad14' }
        }
      ]
    };
  };

  const getRadarOption = () => {
    const filtered = getFilteredData();
    if (filtered.length === 0) return {};

    const subjects = [...new Set(data.filter(d => 
      d.schoolYear === filter.schoolYear && 
      d.semester === filter.semester &&
      d.grade === filter.grade
    ).map(d => d.subject))];

    return {
      title: { text: '班级多学科雷达图', left: 'center' },
      legend: {
        data: filtered.map(d => `${d.classNum}班`),
        bottom: 0
      },
      tooltip: {},
      radar: {
        indicator: subjects.map(s => ({ name: s, max: 100 }))
      },
      series: [{
        type: 'radar',
        data: filtered.slice(0, 3).map(d => {
          const classSubjects = subjects.map(s => {
            const sData = data.find(x => 
              x.grade === filter.grade && 
              x.subject === s && 
              x.classNum === d.classNum
            );
            return sData ? sData.compositeIndex * 25 : 0;
          });
          return { value: classSubjects, name: `${d.classNum}班` };
        })
      }]
    };
  };

  const filtered = getFilteredData();
  const tableData = filtered.map(d => ({
    ...d,
    gradeAvg: calcGradeAvgIndex(data, filter.grade, filter.subject),
    diffFromFirst: calcDiffFromFirst(data, d)
  }));

  const columns = [
    { title: '班级', dataIndex: 'classNum', key: 'classNum', render: (v) => `${v}班` },
    { title: '教师', dataIndex: 'teacher', key: 'teacher' },
    { title: '实考人数', dataIndex: 'actualCount', key: 'actualCount' },
    { title: '高分率', dataIndex: 'highRate', key: 'highRate', render: (v) => `${v}%` },
    { title: '及格率', dataIndex: 'passRate', key: 'passRate', render: (v) => `${v}%` },
    { title: '综合指数', dataIndex: 'compositeIndex', key: 'compositeIndex', render: (v) => v?.toFixed(4) },
    { title: '与年级平均差', dataIndex: 'gradeAvg', key: 'gradeAvg', render: (_, r) => {
      const diff = (r.compositeIndex - r.gradeAvg).toFixed(4);
      return <span style={{ color: diff >= 0 ? '#52c41a' : '#ff4d4f' }}>{diff >= 0 ? '+' : ''}{diff}</span>;
    }}
  ];

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">📊 横向对比</h1>
      
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Select
            value={filter.schoolYear}
            style={{ width: 140 }}
            onChange={(val) => setFilter({ ...filter, schoolYear: val })}
            options={schoolYears.map(y => ({ label: y, value: y }))}
          />
          <Select
            value={filter.semester}
            style={{ width: 100 }}
            onChange={(val) => setFilter({ ...filter, semester: val })}
            options={semesters.map(s => ({ label: s, value: s }))}
          />
          <Select
            value={filter.grade}
            style={{ width: 100 }}
            onChange={(val) => setFilter({ ...filter, grade: val })}
            options={grades.map(g => ({ label: `${g}年级`, value: g }))}
          />
          <Select
            value={filter.subject}
            style={{ width: 120 }}
            onChange={(val) => setFilter({ ...filter, subject: val })}
            options={subjects.map(s => ({ label: s, value: s }))}
          />
        </div>
      </Card>

      <Row gutter={16}>
        <Col span={12}>
          <Card>
            <ReactECharts option={getChartOption()} style={{ height: 400 }} />
          </Card>
        </Col>
        <Col span={12}>
          <Card>
            <ReactECharts option={getRadarOption()} style={{ height: 400 }} />
          </Card>
        </Col>
      </Row>

      <Card style={{ marginTop: 16 }}>
        <Table columns={columns} dataSource={tableData} rowKey="id" size="small" pagination={false} />
      </Card>
    </div>
  );
};

export default HorizontalCompare;
