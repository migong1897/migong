import React, { useState, useEffect } from 'react';
import { Row, Col, Card, Statistic, Select, Table, Tag } from 'antd';
import { getAllData } from '../utils/storage';
import { calcAllRates, schoolYears, semesters } from '../utils/calculations';

const Dashboard = () => {
  const [data, setData] = useState([]);
  const [stats, setStats] = useState({
    total: 0,
    gradeCount: 0,
    subjectCount: 0,
    avgIndex: 0
  });
  const [recentData, setRecentData] = useState([]);
  const [filter, setFilter] = useState({ year: null, semester: null });

  useEffect(() => {
    loadData();
  }, [filter]);

  const loadData = () => {
    let allData = getAllData();
    
    if (filter.year) {
      allData = allData.filter(d => d.schoolYear === filter.year);
    }
    if (filter.semester) {
      allData = allData.filter(d => d.semester === filter.semester);
    }
    
    // 计算统计数据
    const gradeSet = new Set(allData.map(d => d.grade));
    const subjectSet = new Set(allData.map(d => d.subject));
    const avgIndex = allData.length > 0 
      ? (allData.reduce((sum, d) => sum + (d.compositeIndex || 0), 0) / allData.length).toFixed(4)
      : 0;
    
    setStats({
      total: allData.length,
      gradeCount: gradeSet.size,
      subjectCount: subjectSet.size,
      avgIndex
    });
    
    setData(allData);
    setRecentData(allData.slice(-10).reverse());
  };

  const columns = [
    { title: '学年度', dataIndex: 'schoolYear', key: 'schoolYear', width: 100 },
    { title: '学期', dataIndex: 'semester', key: 'semester', width: 70 },
    { title: '年级', dataIndex: 'grade', key: 'grade', width: 60 },
    { title: '班级', dataIndex: 'classNum', key: 'classNum', width: 60 },
    { title: '学科', dataIndex: 'subject', key: 'subject', width: 80 },
    { 
      title: '综合指数', 
      dataIndex: 'compositeIndex', 
      key: 'compositeIndex',
      width: 100,
      render: (val) => <span style={{ color: '#1890ff', fontWeight: 'bold' }}>{val || '-'}</span>
    },
  ];

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">📊 首页概览</h1>
      
      <div className="filter-bar" style={{ marginBottom: 24 }}>
        <Select
          placeholder="选择学年度"
          allowClear
          style={{ width: 160 }}
          onChange={(val) => setFilter({ ...filter, year: val })}
          options={schoolYears.map(y => ({ label: y, value: y }))}
        />
        <Select
          placeholder="选择学期"
          allowClear
          style={{ width: 120 }}
          onChange={(val) => setFilter({ ...filter, semester: val })}
          options={semesters.map(s => ({ label: s, value: s }))}
        />
      </div>

      <Row gutter={16}>
        <Col span={6}>
          <Card>
            <Statistic title="数据记录总数" value={stats.total} />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic title="涉及年级数" value={stats.gradeCount} />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic title="涉及学科数" value={stats.subjectCount} />
          </Card>
        </Col>
        <Col span={6}>
          <Card>
            <Statistic 
              title="平均综合指数" 
              value={stats.avgIndex} 
              precision={4}
              valueStyle={{ color: '#1890ff' }}
            />
          </Card>
        </Col>
      </Row>

      <div className="data-table" style={{ marginTop: 24 }}>
        <h3 style={{ marginBottom: 16 }}>最近录入的数据</h3>
        <Table
          columns={columns}
          dataSource={recentData}
          rowKey="id"
          pagination={{ pageSize: 10 }}
          size="small"
        />
      </div>
    </div>
  );
};

export default Dashboard;
