import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Select, Button, Tabs } from 'antd';
import ReactECharts from 'echarts-for-react';
import { getAllData } from '../utils/storage';
import { schoolYears, semesters, grades, subjects } from '../utils/calculations';

const Charts = () => {
  const [data, setData] = useState([]);
  const [filter, setFilter] = useState({
    schoolYear: schoolYears[schoolYears.length - 1],
    semester: '上学期',
    grade: null
  });

  useEffect(() => {
    setData(getAllData());
  }, []);

  const getGradeDistribution = () => ({
    title: { text: '各年级综合指数分布', left: 'center' },
    tooltip: { trigger: 'axis' },
    legend: { data: ['平均综合指数'], bottom: 0 },
    xAxis: { type: 'category', data: [1,2,3,4,5,6].map(g => `${g}年级`) },
    yAxis: { type: 'value', name: '综合指数' },
    series: [{
      name: '平均综合指数',
      type: 'bar',
      data: [1,2,3,4,5,6].map(g => {
        const gradeData = data.filter(d => d.grade === g);
        if (gradeData.length === 0) return 0;
        return (gradeData.reduce((sum, d) => sum + d.compositeIndex, 0) / gradeData.length).toFixed(4);
      }),
      itemStyle: { color: '#1890ff' },
      label: { show: true, position: 'top' }
    }]
  });

  const getSubjectPerformance = () => {
    const subjectData = subjects.map(s => {
      const sData = data.filter(d => d.subject === s);
      return {
        name: s,
        avg: sData.length > 0 ? (sData.reduce((sum, d) => sum + d.compositeIndex, 0) / sData.length).toFixed(4) : 0
      };
    }).sort((a, b) => b.avg - a.avg);

    return {
      title: { text: '各学科平均综合指数排名', left: 'center' },
      tooltip: { trigger: 'axis' },
      grid: { left: '3%', right: '4%', bottom: '3%', containLabel: true },
      xAxis: { type: 'value', name: '综合指数' },
      yAxis: { type: 'category', data: subjectData.map(s => s.name), inverse: true },
      series: [{
        type: 'bar',
        data: subjectData.map(s => ({
          value: s.avg,
          itemStyle: { color: s.avg > 20 ? '#52c41a' : s.avg > 15 ? '#1890ff' : '#ff4d4f' }
        })),
        label: { show: true, position: 'right' }
      }]
    };
  };

  const getPassRateTrend = () => {
    const yearData = schoolYears.slice(-3).map(year => {
      const yearRecords = data.filter(d => d.schoolYear === year);
      const avgPassRate = yearRecords.length > 0 
        ? yearRecords.reduce((sum, d) => sum + d.passRate, 0) / yearRecords.length 
        : 0;
      return { year, avgPassRate };
    });

    return {
      title: { text: '近三年及格率趋势', left: 'center' },
      tooltip: { trigger: 'axis' },
      xAxis: { type: 'category', data: yearData.map(d => d.year) },
      yAxis: { type: 'value', name: '及格率(%)', max: 100 },
      series: [{
        type: 'line',
        data: yearData.map(d => d.avgPassRate.toFixed(2)),
        smooth: true,
        areaStyle: { color: 'rgba(82, 196, 26, 0.3)' },
        lineStyle: { color: '#52c41a', width: 3 },
        itemStyle: { color: '#52c41a' }
      }]
    };
  };

  const getClassRadar = () => {
    const gradeData = filter.grade 
      ? data.filter(d => d.grade === filter.grade)
      : data;

    const subjectsInData = [...new Set(gradeData.map(d => d.subject))];
    const classes = [1,2,3,4,5].filter(c => gradeData.some(d => d.classNum === c));

    return {
      title: { text: filter.grade ? `${filter.grade}年级各班学科对比` : '各班学科对比', left: 'center' },
      legend: { data: classes.map(c => `${c}班`), bottom: 0 },
      tooltip: {},
      radar: {
        indicator: subjectsInData.map(s => ({ name: s, max: 30 }))
      },
      series: [{
        type: 'radar',
        data: classes.map(c => {
          const classData = gradeData.filter(d => d.classNum === c);
          return {
            value: subjectsInData.map(s => {
              const sData = classData.find(x => x.subject === s);
              return sData ? sData.compositeIndex : 0;
            }),
            name: `${c}班`
          };
        })
      }]
    };
  };

  const getPieData = () => {
    const gradeCount = [1,2,3,4,5,6].map(g => {
      const count = data.filter(d => d.grade === g).length;
      return { name: `${g}年级`, value: count };
    }).filter(d => d.value > 0);

    return {
      title: { text: '数据量分布', left: 'center' },
      tooltip: { trigger: 'item' },
      legend: { bottom: 0 },
      series: [{
        type: 'pie',
        radius: ['40%', '70%'],
        data: gradeCount,
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }]
    };
  };

  const tabItems = [
    { key: '1', label: '年级分布', children: (
      <Row gutter={16}>
        <Col span={24}>
          <ReactECharts option={getGradeDistribution()} style={{ height: 400 }} />
        </Col>
      </Row>
    )},
    { key: '2', label: '学科排名', children: (
      <Row gutter={16}>
        <Col span={24}>
          <ReactECharts option={getSubjectPerformance()} style={{ height: 400 }} />
        </Col>
      </Row>
    )},
    { key: '3', label: '趋势分析', children: (
      <Row gutter={16}>
        <Col span={12}>
          <ReactECharts option={getPassRateTrend()} style={{ height: 350 }} />
        </Col>
        <Col span={12}>
          <ReactECharts option={getPieData()} style={{ height: 350 }} />
        </Col>
      </Row>
    )},
    { key: '4', label: '班级对比', children: (
      <Row gutter={16}>
        <Col span={24}>
          <ReactECharts option={getClassRadar()} style={{ height: 400 }} />
        </Col>
      </Row>
    )}
  ];

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">📈 可视化图表</h1>
      
      <Card style={{ marginBottom: 24 }}>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <Select
            value={filter.schoolYear}
            style={{ width: 140 }}
            onChange={(val) => setFilter({ ...filter, schoolYear: val })}
            options={schoolYears.map(y => ({ label: y, value: y }))}
          />
          <Select
            value={filter.semester}
            style={{ width: 100 }}
            onChange={(val) => setFilter({ ...filter, semester: val })}
            options={semesters.map(s => ({ label: s, value: s }))}
          />
          <Select
            value={filter.grade}
            style={{ width: 100 }}
            allowClear
            placeholder="全部年级"
            onChange={(val) => setFilter({ ...filter, grade: val })}
            options={grades.map(g => ({ label: `${g}年级`, value: g }))}
          />
        </div>
      </Card>

      <Card>
        <Tabs items={tabItems} />
      </Card>
    </div>
  );
};

export default Charts;
