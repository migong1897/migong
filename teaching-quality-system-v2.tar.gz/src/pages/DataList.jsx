import React, { useState, useEffect } from 'react';
import { Table, Button, Select, Input, Space, Modal, message, Popconfirm } from 'antd';
import { EditOutlined, DeleteOutlined, SearchOutlined } from '@ant-design/icons';
import { getAllData, updateRecord, deleteRecord } from '../utils/storage';
import { schoolYears, semesters, grades, classes, subjects } from '../utils/calculations';
import { exportExcel } from '../utils/export';

const DataList = () => {
  const [data, setData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [filters, setFilters] = useState({
    schoolYear: null,
    semester: null,
    grade: null,
    subject: null,
    keyword: ''
  });
  const [editingRecord, setEditingRecord] = useState(null);
  const [editValues, setEditValues] = useState({});

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setLoading(true);
    const allData = getAllData();
    setData(allData);
    setFilteredData(allData);
    setLoading(false);
  };

  useEffect(() => {
    let filtered = [...data];
    
    if (filters.schoolYear) {
      filtered = filtered.filter(d => d.schoolYear === filters.schoolYear);
    }
    if (filters.semester) {
      filtered = filtered.filter(d => d.semester === filters.semester);
    }
    if (filters.grade) {
      filtered = filtered.filter(d => d.grade === filters.grade);
    }
    if (filters.subject) {
      filtered = filtered.filter(d => d.subject === filters.subject);
    }
    if (filters.keyword) {
      filtered = filtered.filter(d => 
        d.teacher?.includes(filters.keyword) ||
        String(d.grade).includes(filters.keyword) ||
        String(d.classNum).includes(filters.keyword)
      );
    }
    
    setFilteredData(filtered);
  }, [filters, data]);

  const handleDelete = (id) => {
    deleteRecord(id);
    message.success('删除成功');
    loadData();
  };

  const handleExport = () => {
    exportExcel(filteredData);
    message.success('导出成功');
  };

  const columns = [
    { title: '学年度', dataIndex: 'schoolYear', key: 'schoolYear', width: 100 },
    { title: '学期', dataIndex: 'semester', key: 'semester', width: 70 },
    { title: '年级', dataIndex: 'grade', key: 'grade', width: 60 },
    { title: '班级', dataIndex: 'classNum', key: 'classNum', width: 60 },
    { title: '学科', dataIndex: 'subject', key: 'subject', width: 80 },
    { title: '教师', dataIndex: 'teacher', key: 'teacher', width: 80 },
    { title: '实考', dataIndex: 'actualCount', key: 'actualCount', width: 60 },
    { title: '人平分', dataIndex: 'avgScore', key: 'avgScore', width: 70 },
    { 
      title: '综合指数', 
      dataIndex: 'compositeIndex', 
      key: 'compositeIndex',
      width: 100,
      render: (val) => <span style={{ color: '#1890ff', fontWeight: 'bold' }}>{val?.toFixed(4) || '-'}</span>
    },
    {
      title: '操作',
      key: 'action',
      width: 120,
      render: (_, record) => (
        <Space>
          <Button 
            type="link" 
            size="small" 
            icon={<EditOutlined />}
            onClick={() => {
              setEditingRecord(record);
              setEditValues(record);
            }}
          >
            编辑
          </Button>
          <Popconfirm
            title="确定删除这条记录吗？"
            onConfirm={() => handleDelete(record.id)}
          >
            <Button type="link" size="small" danger icon={<DeleteOutlined />}>
              删除
            </Button>
          </Popconfirm>
        </Space>
      )
    }
  ];

  return (
    <div style={{ paddingLeft: 260 }}>
      <h1 className="page-title">📋 数据列表</h1>
      
      <div className="filter-bar">
        <Select
          placeholder="学年度"
          allowClear
          style={{ width: 140 }}
          onChange={(val) => setFilters({ ...filters, schoolYear: val })}
          options={schoolYears.map(y => ({ label: y, value: y }))}
        />
        <Select
          placeholder="学期"
          allowClear
          style={{ width: 100 }}
          onChange={(val) => setFilters({ ...filters, semester: val })}
          options={semesters.map(s => ({ label: s, value: s }))}
        />
        <Select
          placeholder="年级"
          allowClear
          style={{ width: 100 }}
          onChange={(val) => setFilters({ ...filters, grade: val })}
          options={grades.map(g => ({ label: `${g}年级`, value: g }))}
        />
        <Select
          placeholder="学科"
          allowClear
          style={{ width: 120 }}
          onChange={(val) => setFilters({ ...filters, subject: val })}
          options={subjects.map(s => ({ label: s, value: s }))}
        />
        <Input
          placeholder="搜索教师/班级"
          prefix={<SearchOutlined />}
          style={{ width: 160 }}
          onChange={(e) => setFilters({ ...filters, keyword: e.target.value })}
        />
        <Button onClick={handleExport} type="primary">
          导出Excel
        </Button>
      </div>

      <div className="data-table">
        <Table
          columns={columns}
          dataSource={filteredData}
          rowKey="id"
          loading={loading}
          pagination={{ pageSize: 15, showSizeChanger: true, showTotal: (total) => `共 ${total} 条` }}
        />
      </div>

      <Modal
        title="编辑记录"
        open={!!editingRecord}
        onOk={() => {
          updateRecord(editingRecord.id, editValues);
          message.success('更新成功');
          setEditingRecord(null);
          loadData();
        }}
        onCancel={() => setEditingRecord(null)}
      >
        <p>编辑功能开发中...</p>
      </Modal>
    </div>
  );
};

export default DataList;
