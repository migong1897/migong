import React, { useMemo } from 'react';
import { Card, Row, Col, Select, Table, Alert, Divider, Statistic } from 'antd';
import { 
  CheckCircleOutlined, 
  WarningOutlined, 
  RiseOutlined, 
  FallOutlined,
  TrophyOutlined,
  TeamOutlined
} from '@ant-design/icons';
import Header from '../components/Header.jsx';
import Sidebar from '../components/Sidebar.jsx';
import { getAllData, getAllSchoolYears, getAllSubjects, getAllGrades } from '../utils/storage.js';
import { calculateAllFields, enrichRecordWithComparisons } from '../utils/calculations.js';
import ReactECharts from 'echarts-for-react';

const { Option } = Select;

const Reports = () => {
  const allData = getAllData();
  const schoolYears = getAllSchoolYears();
  const subjects = getAllSubjects();
  const grades = getAllGrades();

  // 处理数据
  const processedData = useMemo(() => {
    return allData.map(record => {
      const calculated = calculateAllFields(record);
      return enrichRecordWithComparisons(calculated, allData);
    });
  }, [allData]);

  // 整体分析
  const overallAnalysis = useMemo(() => {
    if (processedData.length === 0) {
      return {
        totalRecords: 0,
        avgCompositeIndex: 0,
        maxCompositeIndex: 0,
        minCompositeIndex: 0,
        excellentRate: 0,
        passRate: 0,
        lowScoreRate: 0
      };
    }

    const indices = processedData.map(r => r.综合指数 || 0);
    const avgCompositeIndex = indices.reduce((a, b) => a + b, 0) / indices.length;
    const maxCompositeIndex = Math.max(...indices);
    const minCompositeIndex = Math.min(...indices);
    
    const excellentCount = processedData.filter(r => (r.综合指数 || 0) >= 30).length;
    const passCount = processedData.filter(r => (r.综合指数 || 0) >= 20).length;
    const lowScoreCount = processedData.filter(r => (r.综合指数 || 0) < 15).length;
    
    return {
      totalRecords: processedData.length,
      avgCompositeIndex: avgCompositeIndex.toFixed(4),
      maxCompositeIndex: maxCompositeIndex.toFixed(4),
      minCompositeIndex: minCompositeIndex.toFixed(4),
      excellentRate: ((excellentCount / processedData.length) * 100).toFixed(2),
      passRate: ((passCount / processedData.length) * 100).toFixed(2),
      lowScoreRate: ((lowScoreCount / processedData.length) * 100).toFixed(2)
    };
  }, [processedData]);

  // 优秀班级
  const topClasses = useMemo(() => {
    return [...processedData]
      .sort((a, b) => (b.综合指数 || 0) - (a.综合指数 || 0))
      .slice(0, 5)
      .map(r => ({
        key: r.id,
        class: `${r.年级}-${r.班级}`,
        subject: r.学科,
        teacher: r.任课教师,
        compositeIndex: (r.综合指数 || 0).toFixed(4)
      }));
  }, [processedData]);

  // 需关注班级
  const concernClasses = useMemo(() => {
    return processedData
      .filter(r => (r.综合指数 || 0) < 20)
      .sort((a, b) => (a.综合指数 || 0) - (b.综合指数 || 0))
      .slice(0, 5)
      .map(r => ({
        key: r.id,
        class: `${r.年级}-${r.班级}`,
        subject: r.学科,
        teacher: r.任课教师,
        compositeIndex: (r.综合指数 || 0).toFixed(4)
      }));
  }, [processedData]);

  // 学科分析
  const subjectAnalysis = useMemo(() => {
    const subjectMap = {};
    
    processedData.forEach(record => {
      const subject = record.学科;
      if (!subject) return;
      
      if (!subjectMap[subject]) {
        subjectMap[subject] = { total: 0, count: 0 };
      }
      subjectMap[subject].total += record.综合指数 || 0;
      subjectMap[subject].count += 1;
    });
    
    return Object.entries(subjectMap)
      .map(([subject, data]) => ({
        subject,
        avgIndex: data.count > 0 ? (data.total / data.count).toFixed(4) : 0,
        recordCount: data.count
      }))
      .sort((a, b) => parseFloat(b.avgIndex) - parseFloat(a.avgIndex));
  }, [processedData]);

  // 生成分析报告
  const reportContent = useMemo(() => {
    if (processedData.length === 0) {
      return '暂无数据，请先录入教学数据。';
    }

    const parts = [];
    
    parts.push(`一、整体概况`);
    parts.push(`本次分析共涉及 ${processedData.length} 条教学记录。`);
    parts.push(`平均综合指数为 ${overallAnalysis.avgCompositeIndex}，`);
    parts.push(`最高综合指数为 ${overallAnalysis.maxCompositeIndex}，`);
    parts.push(`最低综合指数为 ${overallAnalysis.minCompositeIndex}。`);
    
    parts.push(`\n二、成绩分布`);
    parts.push(`优秀率（综合指数≥30）: ${overallAnalysis.excellentRate}%`);
    parts.push(`及格率（综合指数≥20）: ${overallAnalysis.passRate}%`);
    parts.push(`需关注率（综合指数<15）: ${overallAnalysis.lowScoreRate}%`);
    
    if (subjectAnalysis.length > 0) {
      const bestSubject = subjectAnalysis[0];
      const worstSubject = subjectAnalysis[subjectAnalysis.length - 1];
      
      parts.push(`\n三、学科分析`);
      parts.push(`表现最佳的学科是 ${bestSubject.subject}，平均综合指数为 ${bestSubject.avgIndex}；`);
      parts.push(`需要重点关注的学科是 ${worstSubject.subject}，平均综合指数为 ${worstSubject.avgIndex}。`);
    }
    
    if (concernClasses.length > 0) {
      parts.push(`\n四、重点关注`);
      parts.push(`以下班级综合指数低于20，需要重点关注和辅导：`);
      concernClasses.forEach((c, i) => {
        parts.push(`  ${i + 1}. ${c.class} ${c.subject}（${c.teacher}）：${c.compositeIndex}`);
      });
    }
    
    parts.push(`\n五、改进建议`);
    if (parseFloat(overallAnalysis.lowScoreRate) > 20) {
      parts.push(`1. 低分率较高，建议加强基础知识教学和个别辅导；`);
    }
    if (parseFloat(overallAnalysis.excellentRate) < 30) {
      parts.push(`2. 优秀率有提升空间，建议开展培优计划；`);
    }
    parts.push(`3. 建议定期跟踪分析，及时发现问题并调整教学策略。`);
    
    return parts.join('\n');
  }, [processedData, overallAnalysis, subjectAnalysis, concernClasses]);

  // 雷达图 - 学科对比
  const radarOption = useMemo(() => {
    const subjects = subjectAnalysis.slice(0, 6);
    return {
      title: { text: '学科综合指数对比', left: 'center' },
      radar: {
        indicator: subjects.map(s => ({ name: s.subject, max: 50 }))
      },
      series: [{
        type: 'radar',
        data: [{
          value: subjects.map(s => parseFloat(s.avgIndex)),
          name: '综合指数'
        }]
      }]
    };
  }, [subjectAnalysis]);

  const topColumns = [
    { title: '班级', dataIndex: 'class', key: 'class' },
    { title: '学科', dataIndex: 'subject', key: 'subject' },
    { title: '教师', dataIndex: 'teacher', key: 'teacher' },
    { title: '综合指数', dataIndex: 'compositeIndex', key: 'compositeIndex',
      render: val => <span style={{ color: '#52c41a', fontWeight: 600 }}>{val}</span> }
  ];

  const concernColumns = [
    { title: '班级', dataIndex: 'class', key: 'class' },
    { title: '学科', dataIndex: 'subject', key: 'subject' },
    { title: '教师', dataIndex: 'teacher', key: 'teacher' },
    { title: '综合指数', dataIndex: 'compositeIndex', key: 'compositeIndex',
      render: val => <span style={{ color: '#ff4d4f', fontWeight: 600 }}>{val}</span> }
  ];

  return (
    <div className="main-layout">
      <Sidebar />
      <div className="content">
        <Header title="智能分析报告" />
        
        <Row gutter={24} style={{ marginBottom: 24 }}>
          <Col span={6}>
            <Card>
              <Statistic 
                title="数据记录" 
                value={overallAnalysis.totalRecords}
                prefix={<TeamOutlined />}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic 
                title="平均综合指数" 
                value={overallAnalysis.avgCompositeIndex}
                precision={4}
                valueStyle={{ color: '#1890ff' }}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic 
                title="优秀率" 
                value={overallAnalysis.excellentRate}
                suffix="%"
                valueStyle={{ color: '#52c41a' }}
                prefix={<TrophyOutlined />}
              />
            </Card>
          </Col>
          <Col span={6}>
            <Card>
              <Statistic 
                title="需关注率" 
                value={overallAnalysis.lowScoreRate}
                suffix="%"
                valueStyle={{ color: '#ff4d4f' }}
                prefix={<WarningOutlined />}
              />
            </Card>
          </Col>
        </Row>

        <Row gutter={24} style={{ marginBottom: 24 }}>
          <Col span={12}>
            <Card title="优秀班级 TOP5">
              {topClasses.length > 0 ? (
                <Table 
                  columns={topColumns} 
                  dataSource={topClasses} 
                  rowKey="key"
                  pagination={false}
                />
              ) : (
                <div style={{ color: '#999', textAlign: 'center', padding: 40 }}>
                  暂无数据
                </div>
              )}
            </Card>
          </Col>
          <Col span={12}>
            <Card title="需关注班级">
              {concernClasses.length > 0 ? (
                <Table 
                  columns={concernColumns} 
                  dataSource={concernClasses} 
                  rowKey="key"
                  pagination={false}
                />
              ) : (
                <div style={{ color: '#52c41a', textAlign: 'center', padding: 40 }}>
                  <CheckCircleOutlined style={{ fontSize: 32, marginBottom: 8 }} />
                  <p>所有班级表现良好！</p>
                </div>
              )}
            </Card>
          </Col>
        </Row>

        <Row gutter={24} style={{ marginBottom: 24 }}>
          <Col span={12}>
            <Card>
              <ReactECharts option={radarOption} style={{ height: 350 }} />
            </Card>
          </Col>
          <Col span={12}>
            <Card title="学科分析">
              <Table
                dataSource={subjectAnalysis}
                rowKey="subject"
                pagination={false}
                columns={[
                  { title: '学科', dataIndex: 'subject', key: 'subject' },
                  { title: '平均综合指数', dataIndex: 'avgIndex', key: 'avgIndex',
                    render: val => (
                      <span style={{ 
                        color: parseFloat(val) >= 30 ? '#52c41a' : 
                               parseFloat(val) >= 20 ? '#1890ff' : '#ff4d4f',
                        fontWeight: 600
                      }}>
                        {val}
                      </span>
                    ) },
                  { title: '记录数', dataIndex: 'recordCount', key: 'recordCount' }
                ]}
              />
            </Card>
          </Col>
        </Row>

        <Card title="分析报告">
          <pre style={{ 
            whiteSpace: 'pre-wrap', 
            fontFamily: 'inherit',
            lineHeight: 1.8,
            color: '#333'
          }}>
            {reportContent}
          </pre>
        </Card>
      </div>
    </div>
  );
};

export default Reports;
